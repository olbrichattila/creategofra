drop table if exists sessions
