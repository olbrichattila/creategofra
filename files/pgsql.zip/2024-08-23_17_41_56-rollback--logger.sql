drop table if exists logs
