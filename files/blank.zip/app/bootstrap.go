// Package boostrap is called when the application starts, regardless of that it is cli or http
package bootstrap

// Bootstrap called when application starts, handles autowire dependencies in the function signature
func Bootstrap() {

}
