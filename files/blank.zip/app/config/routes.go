package appconfig

import (
	"net/http"

	"github.com/olbrichattila/gofra/pkg/app/router"
)

var Routes = []router.ControllerAction{
	{
		Path:        "/",
		RequestType: http.MethodGet,
		Fn: func() map[string]string {
			return map[string]string{"result": "It works"}
		},
	},
}
