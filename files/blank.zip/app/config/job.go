package appconfig

import (
	"github.com/olbrichattila/gofra/pkg/app/cron"
)

var Jobs = []cron.Job{}
