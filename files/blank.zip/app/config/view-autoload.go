package appconfig

var TemplateAutoLoad = map[string][]string{}
