package appconfig

import (
	commandexecutor "github.com/olbrichattila/gofra/pkg/app/command"
)

var ConsoleCommands = map[string]commandexecutor.CommandItem{}
