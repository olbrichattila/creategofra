package appconfig

import middleware "gofraapp/app/middlewares"

// Add middlewares here to execute at every load
var Middlewares = []interface{}{
	middleware.SessionMiddleware,
}
