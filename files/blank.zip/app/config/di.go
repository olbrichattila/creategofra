package appconfig

import "github.com/olbrichattila/gofra/pkg/app/config"

var DiBindings = []config.DiCallback{}
