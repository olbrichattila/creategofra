package middleware

import (
	"net/http"

	"github.com/olbrichattila/gofra/pkg/app/request"
	"github.com/olbrichattila/gofra/pkg/app/session"
)

func AuthorizeMiddleware(w http.ResponseWriter, r request.Requester, s session.Sessioner) bool {
	userId := s.Get("userId")
	if userId == "" {
		http.Redirect(w, r.GetRequest(), "/login", http.StatusSeeOther)
		return false
	}

	return true
}
