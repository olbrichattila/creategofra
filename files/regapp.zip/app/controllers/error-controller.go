package controller

import (
	"github.com/olbrichattila/gofra/pkg/app/session"
	"github.com/olbrichattila/gofra/pkg/app/validator"
	"github.com/olbrichattila/gofra/pkg/app/view"
)

func DisplayError(v view.Viewer, s session.Sessioner, val validator.Validator) string {
	data := map[string]string{
		"lastError": s.Get("lastError"),
	}

	return v.RenderView("error.html", data)
}
