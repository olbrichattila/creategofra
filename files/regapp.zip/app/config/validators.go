package appconfig

import (
	"github.com/olbrichattila/gofra/pkg/app/validator"
)

var ValidatorRules = map[string]validator.RuleFunc{}
