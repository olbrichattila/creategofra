package appconfig

import (
	"html/template"
)

var ViewFuncConfig = template.FuncMap{}
