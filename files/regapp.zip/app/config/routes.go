package appconfig

import (
	controller "gofraapp/app/controllers"
	"net/http"

	"github.com/olbrichattila/gofra/pkg/app/router"
)

var Routes = []router.ControllerAction{
	{
		Path:        "/login",
		RequestType: []string{http.MethodGet},
		Fn:          controller.Login,
	},
	{
		Path:        "/logout",
		RequestType: []string{http.MethodGet},
		Fn:          controller.Logout,
		Middlewares: AuthMiddleware,
	},
	{
		Path:        "/dologin",
		RequestType: []string{http.MethodPost},
		Fn:          controller.LoginPost,
	},
	{
		Path:        "/register",
		RequestType: []string{http.MethodGet},
		Fn:          controller.Register,
	},
	{
		Path:            "/doregister",
		RequestType:     []string{http.MethodPost},
		Fn:              controller.PostRegister,
		ValidationRules: "register",
	},
	{
		Path:        "/confirm",
		RequestType: []string{http.MethodGet},
		Fn:          controller.ActivateAction,
	},
	{
		Path:        "/error",
		RequestType: []string{http.MethodGet},
		Fn:          controller.DisplayError,
	},
	{
		Path:        "/password-reminder",
		RequestType: []string{http.MethodGet},
		Fn:          controller.PasswordReminderControllerAction,
	},
	{
		Path:        "/password-reminder",
		RequestType: []string{http.MethodPost},
		Fn:          controller.PasswordReminderPostControllerAction,
	},
	{
		Path:        "/reminder-sent",
		RequestType: []string{http.MethodGet},
		Fn:          controller.PasswordReminderSentControllerAction,
	},
	{
		Path:        "/change_password",
		RequestType: []string{http.MethodGet},
		Fn:          controller.PasswordChangeControllerAction,
	},
	{
		Path:        "/change_password",
		RequestType: []string{http.MethodPost},
		Fn:          controller.PasswordChangePostControllerAction,
	},
	{
		Path:        "/",
		RequestType: []string{http.MethodGet},
		Middlewares: AuthMiddleware,
		Fn: func() map[string]string {
			return map[string]string{"result": "ok"}
		},
	},
}
