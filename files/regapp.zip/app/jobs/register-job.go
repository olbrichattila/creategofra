package job

import (
	"fmt"
	"time"

	"github.com/olbrichattila/gofra/pkg/app/db"
	"github.com/olbrichattila/gofra/pkg/app/logger"
	"github.com/olbrichattila/gofra/pkg/app/mail"
	"github.com/olbrichattila/gofra/pkg/app/queue"
	"github.com/olbrichattila/gofra/pkg/app/view"

	builder "github.com/olbrichattila/gosqlbuilder/pkg"
)

func SendRegistrationEmail(q queue.Quer, m mail.Mailer, v view.Viewer, l logger.Logger) {
	res, err := q.Pull("register")
	if err != nil {
		// That's ok, queue is empty
		return
	}

	email, ok := res["email"]
	if !ok {
		l.Error("Missing email from the message")
		return
	}

	rendered := v.RenderMail("regconfirm.html", res)
	err = m.Send("attila@osoft.hu", email.(string), "Please confirm your email address", rendered)
	if err != nil {
		l.Error(err.Error())
		return
	}

	l.Info(fmt.Sprintf("Registration mail sent to %s", email))
}

func ExpireEmailConfJob(db db.DBer, bd builder.Builder, l logger.Logger) {
	defer db.Close()
	expireAt := time.Now().Add(-1 * time.Minute).Format("2006-01-02 15:04:05")
	sql, err := bd.Select("reg_confirmations").Fields("id", "user_id").Where("created_at", "<", expireAt).AsSQL()
	if err != nil {
		l.Error(err.Error())
		return
	}

	rows := db.QueryAll(sql, bd.GetParams()...)
	confRow := make([]map[string]interface{}, 0)
	for row := range rows {
		confRow = append(confRow, row)
	}
	for _, row := range confRow {
		id := row["id"]
		userId := row["user_id"]

		delUserSql, err := bd.Delete("users").Where("id", "=", userId).AsSQL()
		if err != nil {
			l.Error(err.Error())
			return
		}
		pars := bd.GetParams()
		_, err = db.Execute(delUserSql, pars...)
		if err != nil {
			l.Error(err.Error())
			return
		}

		delConfSql, err := bd.Delete("reg_confirmations").Where("id", "=", id).AsSQL()
		if err != nil {
			l.Error(err.Error())
			return
		}
		delPars := bd.GetParams()
		_, err = db.Execute(delConfSql, delPars...)
		if err != nil {
			l.Error(err.Error())
			return
		}
		l.Info(fmt.Sprintf("User %d ID expired", userId))
	}

	if db.GetLastError() != nil {
		l.Error(db.GetLastError().Error())
		return
	}
}
